package com.project.projectsetting2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSetting2Application {

    public static void main(String[] args) {
        SpringApplication.run(ProjectSetting2Application.class, args);
    }

}
